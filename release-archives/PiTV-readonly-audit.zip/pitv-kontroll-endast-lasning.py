#!/usr/bin/env python3
"""PiTV inventory: strictly read-only, never prints auth token or complete URLs.
Run as Pi's normal user: python3 pitv-kontroll-endast-lasning.py
"""
from pathlib import Path
from collections import Counter
import ast, os, re, shutil, stat, subprocess, sys

HOME = Path.home()
ROOT = HOME / 'pi-tv'
print('=== PiTV: SKRIVSKYDDAD KONTROLL ===')
print('Den här kontrollen ändrar inga filer eller inställningar.')

def flag(label, value):
    print(f'{label}: {value}')

def run(cmd, *, timeout=4):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
        return p.returncode, (p.stdout or '').strip()
    except (OSError, subprocess.TimeoutExpired):
        return -1, ''

def exists(rel):
    p = ROOT / rel
    flag(rel, 'finns' if p.is_file() else 'SAKNAS')
    return p if p.is_file() else None

print('\n[1] System & verktyg')
for cmd in ('chromium','chromium-browser','wtype','wlrctl','wpctl','wlr-randr','labwc'):
    flag(cmd, 'ja' if shutil.which(cmd) else 'saknas')
rc, arch = run(['uname','-m'])
flag('arkitektur', arch if rc == 0 else 'okänd')
rc, ver = run([shutil.which('chromium') or shutil.which('chromium-browser') or '/nonexistent', '--version'])
flag('Chromium-version', ver[:110] if rc == 0 else 'ej tillgänglig')

print('\n[2] Installerade PiTV-filer')
files = {}
for name in ('start.sh','remote.py','phone-remote.html','tv-home.html','remote-token','dpad-extension/manifest.json','dpad-extension/navigation.js'):
    files[name] = exists(name)

print('\n[3] Säkerhet (inga hemligheter visas)')
tokfile = files['remote-token']
if tokfile:
    st=tokfile.stat()
    token=tokfile.read_text(encoding='utf-8').strip()
    flag('token längd', f'{len(token)} tecken')
    flag('token filrättighet', f'{stat.S_IMODE(st.st_mode):04o}' + (' (rekommenderas 0600)' if stat.S_IMODE(st.st_mode) != 0o600 else ' (OK)'))
else:
    token=''
remote=files['remote.py']
if remote:
    raw=remote.read_text(encoding='utf-8')
    try:
        ast.parse(raw)
        flag('remote.py Python-syntax', 'OK')
    except SyntaxError:
        flag('remote.py Python-syntax', 'FEL')
    flag('maskerad HTTP-logg', 'ja' if 'REDACTED' in raw and 'def log_message' in raw else 'saknas/ej verifierad')
    flag('HTTP-bindning', 'alla gränssnitt' if "'0.0.0.0'" in raw else 'annan/okänd')
    flag('nyckel i URL', 'ja' if "parse_qs(parsed.query)" in raw else 'okänt/nej')
    flag('Hem-metod', 'via adressfält' if re.search(r"name\s*==\s*['\"]home['\"][^\n]*\n\s*navigate\(", raw) else ('webbläsarhistorik' if re.search(r"name\s*==\s*['\"]home['\"][^\n]*\n\s*hotkey\(['\"]alt",raw) else 'annat/saknas'))
    flag('Bakåt-metod', 'Alt+Vänster' if re.search(r"name\s*==\s*['\"]back['\"]",raw) and "hotkey('alt', 'Left')" in raw else 'annat')
    flag('svar 200 efter subprocess', 'ja (ej kvittens på TV-skärm)' if "self._response(200, b'{\"ok\":true}'" in raw else 'okänt')

print('\n[4] Start & gränssnitt')
start=files['start.sh']
if start:
    rc, _ = run(['bash','-n',str(start)])
    flag('start.sh Bash-syntax', 'OK' if rc == 0 else 'FEL/ej verifierad')
    s=start.read_text(encoding='utf-8')
    flag('grundläggande keyring-lagring', 'JA: --password-store=basic' if '--password-store=basic' in s else 'nej/okänt')
    flag('automatisk Chromium fullskärm', 'ja' if '--start-fullscreen' in s else 'nej/okänt')
    flag('Chromium laddar D-pad-tillägg', 'ja' if '--load-extension=' in s else 'nej')
    flag('uppstart med fast paus (race-risk)', 'ja' if re.search(r'\bsleep\s+\d+',s) else 'ingen identifierad')
    flag('systemd-supervisering', 'ingen i start.sh (kontrollera separat)' if 'systemctl' not in s else 'finns')
autostart=HOME/'.config/labwc/autostart'
if autostart.is_file():
    text=autostart.read_text(encoding='utf-8',errors='replace')
    n=sum(1 for line in text.splitlines() if 'pi-tv/start.sh' in line and not line.lstrip().startswith('#'))
    flag('aktiva PiTV-rader i labwc/autostart',n)
else:
    flag('labwc/autostart','saknas')
phone=files['phone-remote.html']
if phone:
    html=phone.read_text(encoding='utf-8')
    acts=sorted(set(re.findall(r'data-a\s*=\s*[\'\"]([^\'\"]+)',html)))
    flag('Android-knappar (namn på kommandon)', ', '.join(acts))
    flag('Hem synlig i fjärr', 'ja' if 'home' in acts else 'nej')
    flag('Netflix/Disney snabbknappar', 'ja' if 'netflix' in acts or 'disney' in acts else 'nej')
tv=files['tv-home.html']
if tv:
    html=tv.read_text(encoding='utf-8')
    choices=sorted(set(re.findall(r'data-app\s*=\s*[\'\"]([^\'\"]+)',html)))
    flag('TV-startsidans tjänster', ', '.join(choices))

print('\n[5] Port och loggar: ENBART summering')
rc, sockets=run(['ss','-ltn'])
flag('fjärrport 8765 lyssnar', 'ja' if rc == 0 and re.search(r':8765\s',sockets) else ('nej' if rc == 0 else 'ej kontrollerat'))
logs=HOME/'.cache/pi-tv'
for name in ('remote.log','chromium.log'):
    p=logs/name
    if p.is_file():
        raw=p.read_text(encoding='utf-8',errors='replace')
        flag(name+' storlek',f'{p.stat().st_size} bytes')
        if name=='remote.log':
            flag('remote.log, 200-svar',len(re.findall(r' HTTP/1\.[01][\'\"] 200',raw)))
            flag('remote.log, 403-svar',len(re.findall(r' HTTP/1\.[01][\'\"] 403',raw)))
            flag('remote.log, handlingsfel',raw.count('Remote action failed'))
            if token:
                flag('NUVARANDE nyckel synlig i äldre logg', 'JA: byt/maskera loggar' if token in raw else 'nej')
        if name=='chromium.log':
            flag('chromium.log, GCM-varningar',sum(raw.count(x) for x in ('DEPRECATED_ENDPOINT','QUOTA_EXCEEDED')))
    else: flag(name,'saknas')
print('\n[6] Resultat')
print('Lägg bara in ovanstående UTTSKRIFT i chatten. Skicka aldrig remote-token, fullständiga fjärrlänkar eller omaskerade loggar.')
print('Kontrollen ändrade ingenting.')
